# Tunnel Manager Installation And Updates

Tunnel Manager releases are portable archives. They do not require an
installer, administrator access, or a fixed executable directory. Download
only from the public distribution repository:

https://github.com/helal00/ssh-tunnel-manager-dists/releases

## Verify the download

Download the archive and `SHA256SUMS.txt` from the same release. On Linux or
macOS:

```sh
sha256sum -c SHA256SUMS.txt --ignore-missing
```

On Windows PowerShell:

```powershell
Get-FileHash .\tunnelm_*.zip -Algorithm SHA256
```

Compare the printed hash with the archive entry in `SHA256SUMS.txt`.

## Windows

Extract the ZIP to a normal per-user folder, for example:

```text
C:\Users\alice\Apps\TunnelManager
```

Run `tunnelm.exe`. `tunnelm-cli.exe` provides console diagnostics. The two
WebView executables are support tools and should remain beside the manager.
Normal configuration is stored in `%APPDATA%\TunnelManager\config.toml`, so a
later binary can be extracted to another folder without losing settings.

## Linux And macOS

Extract the matching `tar.gz`, make `tunnelm` executable if needed, and run it:

```sh
tar -xzf tunnelm_*.tar.gz
chmod +x tunnelm
./tunnelm help
```

These archives currently provide the basic command build. Native Linux and
macOS desktop/tray support remains pre-release until interactive platform QA,
code signing, and packaging are complete.

## Updating

1. Quit Tunnel Manager from its tray/menu so manager-owned tunnels stop.
2. Download and verify the new archive.
3. Extract it to a new folder or replace the old program files while Tunnel
   Manager is not running.
4. Start the new binary and check `tunnelm version --json` and Desktop > Package
   Info.

Configuration, machine-local authentication choices, keyring secrets, bridge
state, and notification delivery state live in the operating system's per-user
application-data locations. They are not shipped in release archives and are
not overwritten by a portable update.

## Portable bootstrap

On first run only, a valid generic `config.toml` placed beside the executable
may seed the per-user configuration when no application-data config exists.
Release archives intentionally contain no active `config.toml`, credentials,
private keys, server addresses, usernames, machine paths, or runtime logs.
Bundled files under `examples/` are inert templates and must be edited or
imported explicitly.
