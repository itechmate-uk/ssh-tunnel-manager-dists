# Tunnel Manager Portable Release

Tunnel Manager manages local OpenSSH port forwards and optional application
launch, health, event, notification, remote-service, and Local File Bridge
workflows.

Read `INSTALL.md` before running the package. Verify the archive against the
release `SHA256SUMS.txt`. The files under `examples/` contain placeholder
targets only; they do not contain credentials and are never loaded
automatically.

Windows package:

- `tunnelm.exe`: desktop/tray manager.
- `tunnelm-cli.exe`: console and support command.
- `tunnelm-webview.exe`: no-console WebView diagnostic.
- `tunnelm-webview-cli.exe`: console WebView diagnostic.

Linux and macOS packages currently contain the basic command build. Native
desktop integration on those platforms remains pre-release pending interactive
QA and platform signing.

Tunnel Manager uses the operating system's OpenSSH client and user SSH
configuration. Password retention defaults to memory for the running manager;
persistent retention is explicit and uses the operating system credential
vault. No plaintext credential fallback is provided.

Source repository: https://github.com/helal00/ssh-tunnel-manager

Downloads: https://github.com/helal00/ssh-tunnel-manager-dists/releases
