# Security Policy

Tunnel Manager is not ready for production use.

## Current Security Boundary

- Use system OpenSSH rather than implementing native SSH in v1.
- Do not store SSH passwords or private-key passphrases.
- Build process launches with executable plus argv arrays, not shell interpolation.
- Bind helper APIs to loopback only unless the user explicitly configures otherwise.
- Do not accept arbitrary shell commands from tunneled browser apps.
- Do not log file contents, SSH secrets, private-key passphrases, or browser-provided file bytes.

## Reporting

During early development, report issues directly in the project workspace or repository issue tracker chosen by the maintainer.
